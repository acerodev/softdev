<?php

require_once __DIR__ . '/vendor/autoload.php';
require '../conexion_reportes/r_conexion.php';
require 'numeroletras/CifrasEnLetras.php';
//Incluímos la clase pago
$v=new CifrasEnLetras(); 
$mpdf = new \Mpdf\Mpdf(['mode' => 'utf-8', 'format' => [80, 180]]);
$query = "SELECT
	configuracion.confi_razon_social, 
	configuracion.confi_ruc, 
	configuracion.confi_nombre_representante, 
	configuracion.confi_direccion, 
	configuracion.confi_celular, 
	configuracion.confi_telefono, 
	configuracion.confi_correo, 
	configuracion.config_foto, 
	configuracion.confi_estado, 
	configuracion.confi_url, 
	servicio.servicio_id, 
	servicio.rece_id, 
	recepcion.cliente_id, 
	cliente.cliente_nombres, 
	cliente.cliente_dni, 
	recepcion.rece_equipo, 
	recepcion.rece_adelanto, 
	recepcion.rece_debe, 

	recepcion.motivo_id, 
	motivo.motivo_descripcion, 
	recepcion.marca_id, 
	marca.marca_descripcion, 
	servicio.servicio_monto, 
	servicio.servicio_concepto, 
	servicio.servicio_responsable, 
	DATE_FORMAT(servicio.servicio_fregistro, '%d/%m/%Y') as servicio_fregistro,
	servicio.servicio_entrega,
	GROUP_CONCAT(CONCAT('  ' , recep_equipo.equipo ,  '   ( ', configuracion.confi_moneda,'  ',  recep_equipo.monto , '  ) ' )) AS equipos
FROM
	configuracion,
	servicio
	INNER JOIN
	recepcion
	ON 
		servicio.rece_id = recepcion.rece_id
	INNER JOIN
	cliente
	ON 
		recepcion.cliente_id = cliente.cliente_id
	INNER JOIN
	motivo
	ON 
		recepcion.motivo_id = motivo.motivo_id
	INNER JOIN
	marca
	ON 
		recepcion.marca_id = marca.marca_id
		INNER JOIN recep_equipo ON
		recepcion.rece_id = recep_equipo.rece_id

	where servicio.servicio_id =  '".$_GET['codigo']."'";

	$resultado = $mysqli ->query($query);
while ($row1 = $resultado-> fetch_assoc()){
	$totalpagar=($row1['servicio_monto']);
	//Convertimos el total en letras
	$letra=($v->convertirEurosEnLetras($totalpagar));

	//para ver el logo en la i,presion
	//<h3 style="text-align:center;display: inline-block;margin: 0px;padding: 0px; "><img src="../'.$row1['config_foto'].'" width="45px"></h3><br>

$html.='	
<style>
@page {
	margin: 7mm;
	margin-header: 0mm;
	margin-footer: 0mm;
	odd-footer-name: html_myfooter1;
	}
</style>
	<h3 style="text-align:center;display: inline-block;margin: 0px;padding: 0px; ">'.$row1['confi_razon_social'].'</h3>
	<h5 style="text-align:center;display: inline-block;margin: 0px;padding: 0px;  font-weight:normal;">'.$row1['confi_direccion'].'</h5>	
	<h5 style="text-align:center;display: inline-block;margin: 0px;padding: 0px;  font-weight:normal;">R.U.C '.$row1['confi_ruc'].'</h5>
	<h5 style="text-align:center;display: inline-block;margin: 0px;padding: 0px;  font-weight:normal;">Movil. '.$row1['confi_celular'].'</h5><br>
	

	<b>Ticket N.:</b>&nbsp; T-000'.$row1['servicio_id'].'&nbsp;&nbsp; - &nbsp;&nbsp;'.$row1['servicio_fregistro'].' <br>
	<b>Cliente:</b>&nbsp; '.$row1['cliente_nombres'].'<br>
	<b>Nif:</b>&nbsp; '.$row1['cliente_dni'].'<br>
	<br>
		        &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<b>Datos del Servicio</b><br>
	-------------------------------------------------------------<br>
	<b>Equipo:</b>&nbsp;  '.$row1['equipos'].'<br> 
	<b>Marca:</b>&nbsp; '.$row1['marca_descripcion'].'<br>
	<b>Falla:</b>&nbsp;  '.$row1['servicio_concepto'].'<br>
	<b>Servicio:</b>&nbsp;  '.$row1['motivo_descripcion'].' <br>
	<b>Encargado:</b>&nbsp;  '.$row1['servicio_responsable'].' <br>
	<b>Estado:</b>&nbsp;  <b>'.$row1['servicio_entrega'].' </b><br>
	<b>N. Refe.:</b>&nbsp;  R-000'.$row1['rece_id'].' <br>

	-------------------------------------------------------------<br>';


	if ($row1['rece_adelanto'] > 0) {
        $html.='
	<h4 style="text-align:right;display: inline-block;margin: 0px;padding: 0px;  font-weight:normal;">Adelanto $.: '.$row1['rece_adelanto'].'</h4>
	<h4 style="text-align:right;display: inline;margin: 0px;padding: 0px;  font-weight:normal;">Pendiente $.: '.$row1['rece_debe'].'</h4>
	<h4 style="text-align:right; margin: 0px;padding: 0px; ">Monto $.: '.$row1['servicio_monto'].'</h4><br>';
	}else{
        	$html.='<h4 style="text-align:right; margin: 0px;padding: 0px; ">Monto $.: '.$row1['servicio_monto'].'</h4><br>';
        }

$html.='
	<table>
	        <thead>
	        <tr>
            	
            	<td style="text-align:left;font-size:11px"><b>SON:</b> '.strtoupper($letra).'</td>

       </tr>

             <tr>
            	<td style="text-align:center;">
	            <barcode code="'.$row1['cliente_nombres'].'|'.$row1['cliente_dni'].'|'.$row1['rece_equipo'].'|'.$row1['servicio_monto'].'|'.$row1['servicio_entrega'].'|" type="QR" class="barcode" size="0.5" disableborder="1" />
	            </td>
              </tr>
              <tr>
	           	<td style="text-align:center;" ><b>Gracias por su preferencia.!</b></td>  
	          </tr>
	        </thead>
	  </table>
<br>
	  <h6 style="text-align:justify; margin: 0px;padding: 0px; ">IVA no inclu&iacute;do. Si el terminal no se puede comprobar no somos responsables de los componentes que no funcionen correctamente. Garant&iacute;a 3 meses no cubre golpes ni humedad. </h6><br>

         
         ';









}

$css = file_get_contents('css/style_rece.css');
$mpdf->WriteHTML($css,1);
$mpdf->WriteHTML(utf8_encode($html));
$mpdf->Output();