<?php

require_once __DIR__ . '/vendor/autoload.php';
require '../conexion_reportes/r_conexion.php';
$mpdf = new \Mpdf\Mpdf(['mode' => 'utf-8', 'format' => [70, 50]]);
$query = "SELECT
	configuracion.confi_razon_social, 
	configuracion.confi_ruc, 
	configuracion.confi_nombre_representante, 
	configuracion.confi_direccion, 
	configuracion.confi_celular, 
	configuracion.confi_telefono, 
	configuracion.confi_correo, 
	configuracion.config_foto, 
	configuracion.confi_estado, 
	configuracion.confi_url, 
	recepcion.rece_id, 
	recepcion.cliente_id, 
	cliente.cliente_nombres, 
	cliente.cliente_celular, 
	cliente.cliente_dni, 
	recepcion.rece_equipo, 
	recepcion.rece_caracteristicas, 
	recepcion.motivo_id, 
	motivo.motivo_descripcion, 
	CONCAT_WS(' - ',recepcion.rece_equipo,recepcion.rece_concepto) as motivo,
	recepcion.rece_concepto, 
	recepcion.rece_monto, 
	DATE_FORMAT(recepcion.rece_fregistro, '%d/%m/%Y') as rece_fregistro,
	recepcion.rece_estado, 
	recepcion.rece_adelanto, 
	recepcion.rece_debe,
	recepcion.rece_accesorios, 
	recepcion.rece_fentrega, 
	recepcion.marca_id, 
    recepcion.rece_serie, 
	marca.marca_descripcion,
	recepcion.rece_cod,
	-- GROUP_CONCAT(CONCAT('  ' , recep_equipo.equipo ,  '  (',  recep_equipo.serie , ') ' )) AS equipos
	GROUP_CONCAT(CONCAT(  '  ',  recep_equipo.serie , ' ' )) AS equipos
FROM
	configuracion,
	recepcion
	INNER JOIN
	cliente
	ON 
		recepcion.cliente_id = cliente.cliente_id
	INNER JOIN
	motivo
	ON 
		recepcion.motivo_id = motivo.motivo_id
	INNER JOIN
	marca
	ON 
		recepcion.marca_id = marca.marca_id 
	INNER JOIN recep_equipo ON
		recepcion.rece_id = recep_equipo.rece_id

	where recepcion.rece_id =  '".$_GET['codigo']."'";

	$resultado = $mysqli ->query($query);
while ($row1 = $resultado-> fetch_assoc()){



$html.='
<style>
@page {
	margin: 5mm;
	margin-header: 0mm;
	margin-footer: 0mm;
	odd-footer-name: html_myfooter1;
	}
</style>


	<h3 style="text-align:center;display: inline-block;margin: 0px;padding: 0px; ">'.$row1['confi_razon_social'].'</h3>
	---------------------------------------------------------<br>
	N. Orden&nbsp;:&nbsp;&nbsp;&nbsp;&nbsp; 00'.$row1['rece_id'].'&nbsp;&nbsp; - &nbsp;&nbsp;'.$row1['rece_fregistro'].' <br>
   	Cliente &nbsp;&nbsp; :&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; '.$row1['cliente_nombres'].'<br>
    Modelo &nbsp;&nbsp; :&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; '.$row1['rece_caracteristicas'].'<br>
    Serie &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;:&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; '.$row1['equipos'].'<br>
    Falla &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;:&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; '.$row1['rece_concepto'].'<br>
	Codigo &nbsp;&nbsp;&nbsp;:&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; '.$row1['rece_cod'].'<br>
	';


}

$css = file_get_contents('css/style_rece.css');
$mpdf->WriteHTML($css,1);
$mpdf->WriteHTML(utf8_encode($html));
$mpdf->Output();